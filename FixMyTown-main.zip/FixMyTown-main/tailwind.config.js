/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/Pages/*.{js,jsx}"],
  theme: {
    extend: {},
  },
  plugins: [],
}

